var searchData=
[
  ['chat',['Chat',['../class_chat.html#a91a76d5af693d46468ee876313ba7afe',1,'Chat']]],
  ['client',['Client',['../class_chat_1_1_client.html#a4d66bd0f3bc141314127bc43806cbe6e',1,'Chat::Client']]]
];
