var searchData=
[
  ['server',['Server',['../class_chat_1_1_server.html#a40ee17c05416aed06445215afb74effe',1,'Chat::Server']]]
];
