var searchData=
[
  ['peer',['Peer',['../class_chat_1_1_peer.html#a1ec840ef8993a9ac190db6d6f92b6c01',1,'Chat.Peer.Peer(String id, String ip, int port)'],['../class_chat_1_1_peer.html#a9375050c0c6930ac28dc49cd9ded1029',1,'Chat.Peer.Peer(String id, int port)']]]
];
