var searchData=
[
  ['equals',['equals',['../class_transaction.html#a076579f7f071ed1f9a5965ba3df93d3d',1,'Transaction']]]
];
