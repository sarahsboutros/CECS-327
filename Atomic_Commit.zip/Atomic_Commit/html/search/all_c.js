var searchData=
[
  ['operation',['Operation',['../enum_transaction_1_1_operation.html',1,'Transaction']]]
];
