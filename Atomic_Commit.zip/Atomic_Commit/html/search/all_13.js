var searchData=
[
  ['yes',['YES',['../enum_transaction_1_1_vote.html#aed6b7af6e6dcd76d1184902ac18120c5',1,'Transaction::Vote']]]
];
