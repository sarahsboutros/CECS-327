var searchData=
[
  ['setcoordinator',['setCoordinator',['../class_transaction.html#ac837c02ec29a6e85808c510e2dfb38b5',1,'Transaction']]],
  ['setpredecessor',['setPredecessor',['../class_chord.html#aca7c1eee8f6e3a72f37b97adb36536fd',1,'Chord.setPredecessor()'],['../interface_chord_message_interface.html#a652d237d05d545cbc7af63526f7c380c',1,'ChordMessageInterface.setPredecessor()']]],
  ['setsuccessor',['setSuccessor',['../class_chord.html#a7de61846981d5fd1b7a9b8a6c653dc76',1,'Chord.setSuccessor()'],['../interface_chord_message_interface.html#a7ce6fa7f748313cb4a5884c868aa2c40',1,'ChordMessageInterface.setSuccessor()']]],
  ['stabilize',['stabilize',['../class_chord.html#a8a4b7a1cd88cb3f607ada0629f2ff2dd',1,'Chord']]]
];
