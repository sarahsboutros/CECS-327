var searchData=
[
  ['no',['NO',['../enum_transaction_1_1_vote.html#a064fe7ee4f7070c4c3c269dd684617b5',1,'Transaction::Vote']]]
];
