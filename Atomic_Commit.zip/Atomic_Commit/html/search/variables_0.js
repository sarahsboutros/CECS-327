var searchData=
[
  ['delete',['DELETE',['../enum_transaction_1_1_operation.html#ad59773f4deb35fcf87cc3d1861ca7d7e',1,'Transaction::Operation']]]
];
