var searchData=
[
  ['vote',['Vote',['../enum_transaction_1_1_vote.html',1,'Transaction']]]
];
